self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "09c78e220b109b8a8957b762348a8032",
    "url": "./index.html"
  },
  {
    "revision": "6b123012d5d5be55aac0",
    "url": "./static/css/2.6b8ea073.chunk.css"
  },
  {
    "revision": "25007b85727547286b55",
    "url": "./static/css/main.62b1328e.chunk.css"
  },
  {
    "revision": "6b123012d5d5be55aac0",
    "url": "./static/js/2.90ed3af2.chunk.js"
  },
  {
    "revision": "fdcaaacd81b601f7b670246b120cf148",
    "url": "./static/js/2.90ed3af2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "25007b85727547286b55",
    "url": "./static/js/main.06245235.chunk.js"
  },
  {
    "revision": "b510f3c1e29e7489c0d2",
    "url": "./static/js/runtime-main.fb776cef.js"
  },
  {
    "revision": "5803d3dc3287191015a64146c13d8a3f",
    "url": "./static/media/Logo-govpl-WHITE.5803d3dc.svg"
  },
  {
    "revision": "5dd9bbed24dac341abc723d1a62dfc48",
    "url": "./static/media/Logo-govpl.5dd9bbed.svg"
  },
  {
    "revision": "759ea19bccf8a5ca50a58e474aced157",
    "url": "./static/media/OpenSans-Bold.759ea19b.woff"
  },
  {
    "revision": "93fe8f3415688d16bb947e2c96ea380e",
    "url": "./static/media/OpenSans-Bold.93fe8f34.woff2"
  },
  {
    "revision": "559e978f49dc58dbe4213c714d308483",
    "url": "./static/media/OpenSans-Light.559e978f.woff2"
  },
  {
    "revision": "c002a58fc48427af4884fcce2d5c03ee",
    "url": "./static/media/OpenSans-Light.c002a58f.woff"
  },
  {
    "revision": "5d5735e57127db2f7a2ad879fc6056b8",
    "url": "./static/media/OpenSans-Regular.5d5735e5.woff2"
  },
  {
    "revision": "6fde2eb6728eb97fd914dcd0641d332b",
    "url": "./static/media/OpenSans-Regular.6fde2eb6.woff"
  },
  {
    "revision": "7106bb83a0e767e12659de9cfba3926d",
    "url": "./static/media/OpenSans-SemiBold.7106bb83.woff2"
  },
  {
    "revision": "fe241c6c4f5a190e821b7c03e337d756",
    "url": "./static/media/OpenSans-SemiBold.fe241c6c.woff"
  },
  {
    "revision": "f2c37e8488c0422a7380253048041b89",
    "url": "./static/media/SafeSafe-dolne-menu-Home-white.f2c37e84.svg"
  },
  {
    "revision": "9e7a28b9790520becee90abc3532bbfc",
    "url": "./static/media/SafeSafe-dolne-menu-More-white.9e7a28b9.svg"
  },
  {
    "revision": "8f1a758287dddbba9d5d900d8c5015eb",
    "url": "./static/media/SafeSafe-dolne-menu-important-info.8f1a7582.svg"
  },
  {
    "revision": "5f94172461af4e6f1755d8a44c41e40a",
    "url": "./static/media/activities-icon-1.5f941724.svg"
  },
  {
    "revision": "bd34118f34096a407b5bb0a4451d546e",
    "url": "./static/media/activities-icon-2.bd34118f.svg"
  },
  {
    "revision": "47d6eca62d792789adc6fe19c9f019fc",
    "url": "./static/media/activities-icon-3.47d6eca6.svg"
  },
  {
    "revision": "2f0263e0853b6f2c798368f73ac87cde",
    "url": "./static/media/ad.2f0263e0.svg"
  },
  {
    "revision": "7df58a71786ed88f50d518a5c6ac1001",
    "url": "./static/media/add-translation.7df58a71.svg"
  },
  {
    "revision": "d038b7ed641db07b673b255136b21993",
    "url": "./static/media/ae.d038b7ed.svg"
  },
  {
    "revision": "14c45ecc69136ef689a20e7b456593f9",
    "url": "./static/media/af.14c45ecc.svg"
  },
  {
    "revision": "8bd07b264ee50f6e93dac01925d8b5bb",
    "url": "./static/media/ag.8bd07b26.svg"
  },
  {
    "revision": "417419b9bb5ab990118e6c27e1fe04df",
    "url": "./static/media/ai.417419b9.svg"
  },
  {
    "revision": "c521e40e04e61f31e814e29ccc5e2d78",
    "url": "./static/media/al.c521e40e.svg"
  },
  {
    "revision": "8b42c952b8e5e282a7bf70ef524118be",
    "url": "./static/media/am.8b42c952.svg"
  },
  {
    "revision": "31a0db43cc183e62ab26489a19c14b6f",
    "url": "./static/media/angle-left.31a0db43.svg"
  },
  {
    "revision": "d2ee292a7539ade03c81d9f9d29e5225",
    "url": "./static/media/angle-right-blue.d2ee292a.svg"
  },
  {
    "revision": "e7a48e3d30e9db396b4e94ca3a968034",
    "url": "./static/media/angle-right-white.e7a48e3d.svg"
  },
  {
    "revision": "902df746b0a51a74ddccbc3b4027777b",
    "url": "./static/media/angle-right.902df746.svg"
  },
  {
    "revision": "2490f4bdc9f6ba4a049e56bbe00dfc9e",
    "url": "./static/media/ao.2490f4bd.svg"
  },
  {
    "revision": "4f098aa50b53a576c2588df26798e978",
    "url": "./static/media/ar.4f098aa5.svg"
  },
  {
    "revision": "4e357f0ea7cae2dd978f76da88e9234b",
    "url": "./static/media/arrow-current-color.4e357f0e.svg"
  },
  {
    "revision": "e0de455073fcd389052034d7bdf4b485",
    "url": "./static/media/as.e0de4550.svg"
  },
  {
    "revision": "e006579c101b01447e2d2d868c167d4e",
    "url": "./static/media/at.e006579c.svg"
  },
  {
    "revision": "ecef4318677ec5821f095be51f2c3c48",
    "url": "./static/media/au.ecef4318.svg"
  },
  {
    "revision": "1eb0d2cdc19a278d33ad0b55329d9656",
    "url": "./static/media/aw.1eb0d2cd.svg"
  },
  {
    "revision": "fa9c079d723e259450fc5b3d1501a2e9",
    "url": "./static/media/az.fa9c079d.svg"
  },
  {
    "revision": "f27ae1eae0f22cf3cb37e46611dcd408",
    "url": "./static/media/ba.f27ae1ea.svg"
  },
  {
    "revision": "4e5817e85388534c1153cf7333bec8d3",
    "url": "./static/media/bad.4e5817e8.svg"
  },
  {
    "revision": "d35efe6b08e42a61ae1e861bf5eb5f1b",
    "url": "./static/media/bb.d35efe6b.svg"
  },
  {
    "revision": "6ab6bba36765f4668f381986a5dde4b0",
    "url": "./static/media/bd.6ab6bba3.svg"
  },
  {
    "revision": "8e6fc60fa23bf9fdace300a03fcc5091",
    "url": "./static/media/be.8e6fc60f.svg"
  },
  {
    "revision": "22fd8460c58d795d635e683ec51e0750",
    "url": "./static/media/bell.22fd8460.svg"
  },
  {
    "revision": "8f06ad55f71a4e15c60496aa556d8fbd",
    "url": "./static/media/bell_selected.8f06ad55.svg"
  },
  {
    "revision": "a6dec3ee26631e98263fc111d94a0f23",
    "url": "./static/media/bf.a6dec3ee.svg"
  },
  {
    "revision": "8a0211a85f69e64609f6f5169bad02ca",
    "url": "./static/media/bg.8a0211a8.svg"
  },
  {
    "revision": "c47c4db191f0271c41f3ccf30666968d",
    "url": "./static/media/bh.c47c4db1.svg"
  },
  {
    "revision": "21c1ff1f4bebbdf2f08aa35a544c1261",
    "url": "./static/media/bi.21c1ff1f.svg"
  },
  {
    "revision": "aa6d71d381196460e1d1ce83b871645a",
    "url": "./static/media/bj.aa6d71d3.svg"
  },
  {
    "revision": "ce5113bcb45a8742a950e4b905db560c",
    "url": "./static/media/bluetooth-module-01.ce5113bc.svg"
  },
  {
    "revision": "24e1d8fca491f29f399f711e7f5afe94",
    "url": "./static/media/bluetooth.24e1d8fc.svg"
  },
  {
    "revision": "e28367a1f8ab84e9762806a13169b793",
    "url": "./static/media/bm.e28367a1.svg"
  },
  {
    "revision": "197a9d2042c864c30cc3620f004443bb",
    "url": "./static/media/bo.197a9d20.svg"
  },
  {
    "revision": "8909bc2f8e7e1074b02423dc6623dc2c",
    "url": "./static/media/br.8909bc2f.svg"
  },
  {
    "revision": "cbc1054504e15571bc38756094256810",
    "url": "./static/media/bs.cbc10545.svg"
  },
  {
    "revision": "f5f3492232cfd6196a2764887e68f0b6",
    "url": "./static/media/bt.f5f34922.svg"
  },
  {
    "revision": "6c2cdb0c06e00cdf4ddf483396b33244",
    "url": "./static/media/bw.6c2cdb0c.svg"
  },
  {
    "revision": "ad33ee06faf23c06d0a6b208a5148c56",
    "url": "./static/media/by.ad33ee06.svg"
  },
  {
    "revision": "c6b9ed7bc99a7a4c317e05ed301999b7",
    "url": "./static/media/bz.c6b9ed7b.svg"
  },
  {
    "revision": "ea6532d7b9cda969352affc0cc5a7ffc",
    "url": "./static/media/ca.ea6532d7.svg"
  },
  {
    "revision": "ec94f424c0b152bbb31aa963524f4c0b",
    "url": "./static/media/calendar.ec94f424.svg"
  },
  {
    "revision": "eaf9c22471a60304940d9acce3f1314d",
    "url": "./static/media/cd.eaf9c224.svg"
  },
  {
    "revision": "037865b5c116397f4a8c9d969c8de727",
    "url": "./static/media/cf.037865b5.svg"
  },
  {
    "revision": "c2f55ad5ac783bbb7e40cd0d212728d9",
    "url": "./static/media/cg.c2f55ad5.svg"
  },
  {
    "revision": "f0617e6d1572194298e4bc6886677275",
    "url": "./static/media/ch.f0617e6d.svg"
  },
  {
    "revision": "4e4696288549f7ed8df40f765627397b",
    "url": "./static/media/chat.4e469628.svg"
  },
  {
    "revision": "b645505de9c21f9b7bdf9f9595eb164a",
    "url": "./static/media/check-white.b645505d.svg"
  },
  {
    "revision": "02796bef5bf42f89edf80fd268f77395",
    "url": "./static/media/ci.02796bef.svg"
  },
  {
    "revision": "d70c0467752097e99b3466d64a203216",
    "url": "./static/media/circle-loader.d70c0467.svg"
  },
  {
    "revision": "0e4eaabf8f668c922f676fe07cbeaeaf",
    "url": "./static/media/ck.0e4eaabf.svg"
  },
  {
    "revision": "dfefa273f01ddbd6341785f8d1d6a5e7",
    "url": "./static/media/cl.dfefa273.svg"
  },
  {
    "revision": "2b7529e8fa20c7c1516d7ce6ecbff8f7",
    "url": "./static/media/close-modal.2b7529e8.svg"
  },
  {
    "revision": "5ae5eba985cc91bd9be3220f13c94b9b",
    "url": "./static/media/close.5ae5eba9.svg"
  },
  {
    "revision": "4982702b39b79a43c96ead01f9cc6510",
    "url": "./static/media/cm.4982702b.svg"
  },
  {
    "revision": "ce4c8db3eda99fd12c799cc3def054ec",
    "url": "./static/media/cn.ce4c8db3.svg"
  },
  {
    "revision": "714d1724a2b3323651e3a4d380f644d6",
    "url": "./static/media/co.714d1724.svg"
  },
  {
    "revision": "46b19aa9b98b0ef48c79e647016ab886",
    "url": "./static/media/cr.46b19aa9.svg"
  },
  {
    "revision": "7797b415b2ef9d2eccbd67c6a8b133c7",
    "url": "./static/media/cu.7797b415.svg"
  },
  {
    "revision": "10bc0622c831aac134b1003cd26c846a",
    "url": "./static/media/cv.10bc0622.svg"
  },
  {
    "revision": "93e442a035a9ef88549ae21fe50ecfad",
    "url": "./static/media/cw.93e442a0.svg"
  },
  {
    "revision": "59aa3a041705c3ad5c1cd6c0ea3f8ea3",
    "url": "./static/media/cy.59aa3a04.svg"
  },
  {
    "revision": "072878bc70d214fba1acda6ac3fcd23d",
    "url": "./static/media/cz.072878bc.svg"
  },
  {
    "revision": "b55ae913a982896139703572a8520de9",
    "url": "./static/media/de.b55ae913.svg"
  },
  {
    "revision": "159e9f2660c339f18a542526799a5cc7",
    "url": "./static/media/diagnostic.159e9f26.svg"
  },
  {
    "revision": "f5ae9f756a7c912ccc3e525eb7788302",
    "url": "./static/media/diary.f5ae9f75.svg"
  },
  {
    "revision": "556d36eab84f856583904c8244db2cf9",
    "url": "./static/media/dj.556d36ea.svg"
  },
  {
    "revision": "85d2764498f13edbffd104c464a22b6a",
    "url": "./static/media/dk.85d27644.svg"
  },
  {
    "revision": "eecccf82442b919a15c457be4a2c1b22",
    "url": "./static/media/dm.eecccf82.svg"
  },
  {
    "revision": "48badacfa970821032ebea86fb823213",
    "url": "./static/media/do.48badacf.svg"
  },
  {
    "revision": "29c9e0c54a0d641d1cfe0579538a2942",
    "url": "./static/media/dz.29c9e0c5.svg"
  },
  {
    "revision": "f20bd7777366a7f1a18e032683fb112d",
    "url": "./static/media/dziennik_zdrowia.f20bd777.svg"
  },
  {
    "revision": "ca34fc752115caa19ae433e41aa73a5f",
    "url": "./static/media/ec.ca34fc75.svg"
  },
  {
    "revision": "10148440221da3f095e3d73905880661",
    "url": "./static/media/ee.10148440.svg"
  },
  {
    "revision": "e1ba2666aa891c8824eacdd95559ec4d",
    "url": "./static/media/eg.e1ba2666.svg"
  },
  {
    "revision": "49f33adf63f21e2139438c9a73aa77b7",
    "url": "./static/media/en-high.49f33adf.svg"
  },
  {
    "revision": "b320ee4f205cf826c13f9296c25ef76c",
    "url": "./static/media/en-low.b320ee4f.svg"
  },
  {
    "revision": "5d6065ae69e155ee68727231573241ff",
    "url": "./static/media/en-middle.5d6065ae.svg"
  },
  {
    "revision": "4df1e7ea39eff61c0cfc549168db9cc8",
    "url": "./static/media/en.4df1e7ea.svg"
  },
  {
    "revision": "ed8466e00c6fe3db1fc5efedd989ec25",
    "url": "./static/media/er.ed8466e0.svg"
  },
  {
    "revision": "475281bde6c6966dac3e8db69f2eb962",
    "url": "./static/media/error.475281bd.svg"
  },
  {
    "revision": "e6a28e060cab0941e34115ae98196fbc",
    "url": "./static/media/es.e6a28e06.svg"
  },
  {
    "revision": "c788799057c79f1962c2ef6a233f0f43",
    "url": "./static/media/et.c7887990.svg"
  },
  {
    "revision": "4658effd5e031aebe27fe8a2cb45749f",
    "url": "./static/media/european-union.4658effd.svg"
  },
  {
    "revision": "6deb8e6aea18be24a561883ba3b7690a",
    "url": "./static/media/exposure-high.6deb8e6a.svg"
  },
  {
    "revision": "a5cbf21c19462d80378b78f8515b0da8",
    "url": "./static/media/exposure-middle.a5cbf21c.svg"
  },
  {
    "revision": "09c39839ac9627f25dfc877ab2942468",
    "url": "./static/media/face-high.09c39839.svg"
  },
  {
    "revision": "b5be8a8d679d31c80411c20930abd1cf",
    "url": "./static/media/face-low.b5be8a8d.svg"
  },
  {
    "revision": "5e9e318f220295f15b85ca02334bf5ed",
    "url": "./static/media/face-middle.5e9e318f.svg"
  },
  {
    "revision": "1b29841536ce71365e3043bcfb8481b6",
    "url": "./static/media/fi.1b298415.svg"
  },
  {
    "revision": "49f9fa66b09ebc4d201a34c1aee218da",
    "url": "./static/media/fj.49f9fa66.svg"
  },
  {
    "revision": "9144425b215d06dc81c5bff8de72bce6",
    "url": "./static/media/fk.9144425b.svg"
  },
  {
    "revision": "e17c61c3fdad2ed811b52682f4692aca",
    "url": "./static/media/flag-pl.e17c61c3.svg"
  },
  {
    "revision": "3164af6688e4eedc76cfc499247351ef",
    "url": "./static/media/flag-ue.3164af66.svg"
  },
  {
    "revision": "1d9aff75f14e220de9d479d011c60b11",
    "url": "./static/media/fm.1d9aff75.svg"
  },
  {
    "revision": "76d76579677aafe9c87f45d3bf65a5a7",
    "url": "./static/media/fo.76d76579.svg"
  },
  {
    "revision": "0846f86ef6c102ccae38202233181418",
    "url": "./static/media/fr.0846f86e.svg"
  },
  {
    "revision": "f2442ae08584b537efd2c09e5be83531",
    "url": "./static/media/ga.f2442ae0.svg"
  },
  {
    "revision": "4df1e7ea39eff61c0cfc549168db9cc8",
    "url": "./static/media/gb.4df1e7ea.svg"
  },
  {
    "revision": "03bd9ec862668115356d091f9819ed80",
    "url": "./static/media/gd.03bd9ec8.svg"
  },
  {
    "revision": "080272a78753e98cb4fb91f6632aac0c",
    "url": "./static/media/ge.080272a7.svg"
  },
  {
    "revision": "6d36584f4205543deea500c8cd5bfde2",
    "url": "./static/media/gg.6d36584f.svg"
  },
  {
    "revision": "d9949341cb94c7e68380133587722557",
    "url": "./static/media/gh.d9949341.svg"
  },
  {
    "revision": "8bab78ca93b005f295822804b8df244c",
    "url": "./static/media/gi.8bab78ca.svg"
  },
  {
    "revision": "86f5655938c40b4e402fd7248f4085a4",
    "url": "./static/media/gl.86f56559.svg"
  },
  {
    "revision": "814fdc51e9461a52e44292d6520d74c7",
    "url": "./static/media/gm.814fdc51.svg"
  },
  {
    "revision": "6bab8b1e44026e1894368b3b4ff6ed1d",
    "url": "./static/media/gn.6bab8b1e.svg"
  },
  {
    "revision": "a6b912d95c3d743970a12fdca875477b",
    "url": "./static/media/govtech_black.a6b912d9.svg"
  },
  {
    "revision": "f8747f176064d4cbd9844af9a1b6307e",
    "url": "./static/media/govtech_white.f8747f17.svg"
  },
  {
    "revision": "3c96f718967249e267ccb21f44c42340",
    "url": "./static/media/gq.3c96f718.svg"
  },
  {
    "revision": "be0d63c323c808f02c8bd99f787cc556",
    "url": "./static/media/gr.be0d63c3.svg"
  },
  {
    "revision": "e2a8f7ec1d3c521229198e76d00e817f",
    "url": "./static/media/gt.e2a8f7ec.svg"
  },
  {
    "revision": "037043f8dcdf01c5f7f39b256c37cd80",
    "url": "./static/media/gu.037043f8.svg"
  },
  {
    "revision": "47fd8d67bbde73f7a41e707682b07fac",
    "url": "./static/media/gw.47fd8d67.svg"
  },
  {
    "revision": "ead3413cf880ffc22667461aa2b4064b",
    "url": "./static/media/history-activities-empty.ead3413c.svg"
  },
  {
    "revision": "bb078da163b527e5f98a11b1d7524919",
    "url": "./static/media/hk.bb078da1.svg"
  },
  {
    "revision": "ca21772ccd0f0d39dcdd79904a6005e7",
    "url": "./static/media/hn.ca21772c.svg"
  },
  {
    "revision": "908da503946d1c354d83e8168c4d8e08",
    "url": "./static/media/how-it-works.908da503.svg"
  },
  {
    "revision": "5dbad14f458e1cb950a582ad2c710ff5",
    "url": "./static/media/hr.5dbad14f.svg"
  },
  {
    "revision": "b269aba7d4cd009962d9cde279fdac64",
    "url": "./static/media/ht.b269aba7.svg"
  },
  {
    "revision": "70eee4ddf711fa9691203ce564952608",
    "url": "./static/media/hu.70eee4dd.svg"
  },
  {
    "revision": "9c2eba8e858bfb7d5e1b20e562b027b0",
    "url": "./static/media/i-am-sick-icon-1.9c2eba8e.svg"
  },
  {
    "revision": "d1959224a1955253f4c8c96f5c7004af",
    "url": "./static/media/i-am-sick-icon-2.d1959224.svg"
  },
  {
    "revision": "96d3c38edcf7572f85fa1b71e4c3b421",
    "url": "./static/media/i-am-sick-icon-3.96d3c38e.svg"
  },
  {
    "revision": "f6f06573e9e6a523c059762fd0a8c929",
    "url": "./static/media/i-am-sick-icon-4.f6f06573.svg"
  },
  {
    "revision": "819450edb943df797af21c37c3852643",
    "url": "./static/media/i-am-sick-icon-6.819450ed.svg"
  },
  {
    "revision": "250088724318d5369c3cc55a134bb973",
    "url": "./static/media/i-am-sick-icon-7.25008872.svg"
  },
  {
    "revision": "b7d21edfeffcc541d9c14ed73a421dcd",
    "url": "./static/media/icon-check-small.b7d21edf.svg"
  },
  {
    "revision": "058766865e56cc109c86908eb9a12872",
    "url": "./static/media/icon-contact-blue.05876686.svg"
  },
  {
    "revision": "beb05eebe0db71912588936142609f38",
    "url": "./static/media/icon-contact.beb05eeb.svg"
  },
  {
    "revision": "29c1719d7429593fbb5bda9051e83de6",
    "url": "./static/media/icon-covid-tests.29c1719d.svg"
  },
  {
    "revision": "1ffd6b6abbe8c30ad178b984cfe5680d",
    "url": "./static/media/icon-covid.1ffd6b6a.svg"
  },
  {
    "revision": "83bf8d7bb4938a1ffef13fba7cd901c9",
    "url": "./static/media/icon-death.83bf8d7b.svg"
  },
  {
    "revision": "2101142e348cceeafdfd99e8bd9a269b",
    "url": "./static/media/icon-no-data.2101142e.svg"
  },
  {
    "revision": "dbaeb361d869a40149fb5fa7afbd176d",
    "url": "./static/media/icon-recover.dbaeb361.svg"
  },
  {
    "revision": "66b79350b132dc4d119421513dc05cb3",
    "url": "./static/media/icon-rejestracja.66b79350.svg"
  },
  {
    "revision": "f11fd47d548365ce648c438009cea50e",
    "url": "./static/media/icon-statistics-no-data.f11fd47d.svg"
  },
  {
    "revision": "2ed5b9a583bef4c74b6f4f13fdf044d0",
    "url": "./static/media/icon-szczepienie.2ed5b9a5.svg"
  },
  {
    "revision": "f419fa1ee1d569baf5dca344da73249a",
    "url": "./static/media/icon-tlumacz.f419fa1e.svg"
  },
  {
    "revision": "73dc760db71b26aaf700221db6fc5722",
    "url": "./static/media/icon-tlumaczenie_sukces.73dc760d.svg"
  },
  {
    "revision": "b7a6b996b695cd2f17d5085bccd397e8",
    "url": "./static/media/icon-vaccine.b7a6b996.svg"
  },
  {
    "revision": "6d7fc695ffda3f630f801d0aea1f82aa",
    "url": "./static/media/icon-wirus.6d7fc695.svg"
  },
  {
    "revision": "6b254ad7c2b9d7209ab342341f256bda",
    "url": "./static/media/id.6b254ad7.svg"
  },
  {
    "revision": "116f300a4e51d885885102778a3a1a89",
    "url": "./static/media/ie.116f300a.svg"
  },
  {
    "revision": "8cfa7ba12f0b8a7f225c60e91c757f5e",
    "url": "./static/media/il.8cfa7ba1.svg"
  },
  {
    "revision": "3e276e7d8bcbc157eebf3c34bec19fe5",
    "url": "./static/media/im.3e276e7d.svg"
  },
  {
    "revision": "0e0c2bc87df5dde6b80d3d1403d2af1c",
    "url": "./static/media/important-info-1.0e0c2bc8.svg"
  },
  {
    "revision": "c4ba04849eb33746b6edc5fd0883f8c8",
    "url": "./static/media/important-info-2.c4ba0484.svg"
  },
  {
    "revision": "9cef309f46fbdd156cb90cb4c0ecd411",
    "url": "./static/media/important-info-3.9cef309f.svg"
  },
  {
    "revision": "336fdbe03500d9831f27d1e41da7e24f",
    "url": "./static/media/important-info-4.336fdbe0.svg"
  },
  {
    "revision": "07081b0b729cd44bb28517700b8a5cf4",
    "url": "./static/media/important-info-5.07081b0b.svg"
  },
  {
    "revision": "c8a275d25fe8685e84b22fd82a9731cc",
    "url": "./static/media/important-info-6.c8a275d2.svg"
  },
  {
    "revision": "fbb785b316dad839a069eb135fc01e9d",
    "url": "./static/media/important-info-7.fbb785b3.svg"
  },
  {
    "revision": "7fdfdb85c2cbf35c4d8a8e30e27cbc92",
    "url": "./static/media/in.7fdfdb85.svg"
  },
  {
    "revision": "67b513ac050e7889c9d51db582db84d8",
    "url": "./static/media/info-tooltip.67b513ac.svg"
  },
  {
    "revision": "e49bc7d04c8908434f83ca4bb7d48729",
    "url": "./static/media/info-vaccinations-1.e49bc7d0.svg"
  },
  {
    "revision": "0e4739245983d5c2b0436b52860784c0",
    "url": "./static/media/info-vaccinations-2.0e473924.svg"
  },
  {
    "revision": "8b8b3d514b000c8645138682a58fbb40",
    "url": "./static/media/info-vaccinations-3.8b8b3d51.svg"
  },
  {
    "revision": "19d89858cf45f2d3a34cfbbd83901b4a",
    "url": "./static/media/info-vaccinations-4.19d89858.svg"
  },
  {
    "revision": "9170347120c4ab3e6be9426c5f376ddb",
    "url": "./static/media/info-vaccinations-5.91703471.svg"
  },
  {
    "revision": "4e5817e85388534c1153cf7333bec8d3",
    "url": "./static/media/info.4e5817e8.svg"
  },
  {
    "revision": "f16215e1281fce11d05451286aada96c",
    "url": "./static/media/info.f16215e1.svg"
  },
  {
    "revision": "3afb6b16610584ffa8b88003d90ab950",
    "url": "./static/media/interoperability.3afb6b16.svg"
  },
  {
    "revision": "aecf8a976f9550e8f7b2e2c8068014e9",
    "url": "./static/media/io.aecf8a97.svg"
  },
  {
    "revision": "a1520bca28df046942a92d445ed44c38",
    "url": "./static/media/iq.a1520bca.svg"
  },
  {
    "revision": "7c8e6cb3156702fe6be30d30425a2a87",
    "url": "./static/media/ir.7c8e6cb3.svg"
  },
  {
    "revision": "1eecf71d700cb3f18b8188c00de9c181",
    "url": "./static/media/is.1eecf71d.svg"
  },
  {
    "revision": "b46f8792f1641fc6927137c0f162e46c",
    "url": "./static/media/it.b46f8792.svg"
  },
  {
    "revision": "55d15529888cfcb15cb52b8b93ad2f1b",
    "url": "./static/media/je.55d15529.svg"
  },
  {
    "revision": "2fbfcbf15ba4812ecc134b7913c0f809",
    "url": "./static/media/jm.2fbfcbf1.svg"
  },
  {
    "revision": "8f719a67a528c19790f907b7f93acdc4",
    "url": "./static/media/jo.8f719a67.svg"
  },
  {
    "revision": "4187b1d40dd02e84f908f0b2c9d24236",
    "url": "./static/media/jp.4187b1d4.svg"
  },
  {
    "revision": "732c2b397511b291abeb188dec746a38",
    "url": "./static/media/ke.732c2b39.svg"
  },
  {
    "revision": "99318e86009dfc5243eb92721b93d70c",
    "url": "./static/media/kg.99318e86.svg"
  },
  {
    "revision": "ae60a7f636411c3f57dd5a964c8221bb",
    "url": "./static/media/kh.ae60a7f6.svg"
  },
  {
    "revision": "80e19e9bf279ba4b868cbec11a13849a",
    "url": "./static/media/ki.80e19e9b.svg"
  },
  {
    "revision": "7fdeb4b60e4def05a0673545c5a5dd24",
    "url": "./static/media/km.7fdeb4b6.svg"
  },
  {
    "revision": "6819c37bf38fb00b773608eb51b91bf6",
    "url": "./static/media/kn.6819c37b.svg"
  },
  {
    "revision": "69b9a9751ad3f942b3254a29a9c5d5be",
    "url": "./static/media/kp.69b9a975.svg"
  },
  {
    "revision": "5adfd676d31e3b286f072b71c639378c",
    "url": "./static/media/kr.5adfd676.svg"
  },
  {
    "revision": "398bcf751f8e43722092f9b0f10515c9",
    "url": "./static/media/kw.398bcf75.svg"
  },
  {
    "revision": "b7acd796583d3b0eb1c89334c6761a94",
    "url": "./static/media/ky.b7acd796.svg"
  },
  {
    "revision": "130a3907b1b872f554cc897ad767aa70",
    "url": "./static/media/kz.130a3907.svg"
  },
  {
    "revision": "3d622932923c42d8689bf02015788a87",
    "url": "./static/media/la.3d622932.svg"
  },
  {
    "revision": "e9ae2c18af58e7860f64f2baf4b9db25",
    "url": "./static/media/language.e9ae2c18.svg"
  },
  {
    "revision": "5e6ca7227e00e4baaaa70a01e6b5ae18",
    "url": "./static/media/lb.5e6ca722.svg"
  },
  {
    "revision": "64c4108b7211e2356f9258b35aaee81d",
    "url": "./static/media/li.64c4108b.svg"
  },
  {
    "revision": "d5cf9401eb1cf775f0923c6872eff30b",
    "url": "./static/media/lk.d5cf9401.svg"
  },
  {
    "revision": "7f661fb0cc9de268c5304e5f754a0f01",
    "url": "./static/media/lr.7f661fb0.svg"
  },
  {
    "revision": "7528237237f645e204dcd54ef08f0c79",
    "url": "./static/media/ls.75282372.svg"
  },
  {
    "revision": "bc4254416c1598f3b876634f9bd301b7",
    "url": "./static/media/lt.bc425441.svg"
  },
  {
    "revision": "f8137a63210014accfc51d72989bdbf7",
    "url": "./static/media/lu.f8137a63.svg"
  },
  {
    "revision": "616b944497f3027a524433de81a1bd38",
    "url": "./static/media/lupa.616b9444.svg"
  },
  {
    "revision": "d24278f83921e0d7f6832efe37a55d0e",
    "url": "./static/media/lv.d24278f8.svg"
  },
  {
    "revision": "2178201ba5709d7caa1fa7527d883a20",
    "url": "./static/media/ly.2178201b.svg"
  },
  {
    "revision": "68c6eafb3e4cf2035dc9bd8118a371cc",
    "url": "./static/media/ma.68c6eafb.svg"
  },
  {
    "revision": "1c490ba374493e188c3a0cea4b9cd707",
    "url": "./static/media/mapa-pl.1c490ba3.svg"
  },
  {
    "revision": "a6ed56abb83da72636cd48dbf1213fa3",
    "url": "./static/media/mc.a6ed56ab.svg"
  },
  {
    "revision": "d09118bed729a0767548a68afc7e6d81",
    "url": "./static/media/md.d09118be.svg"
  },
  {
    "revision": "0400ec95c6755bd077fff650bd8e32bc",
    "url": "./static/media/me.0400ec95.svg"
  },
  {
    "revision": "57fb6c83820f61563512924e32ed8805",
    "url": "./static/media/menu-boczne-dziennik_BLUE.57fb6c83.svg"
  },
  {
    "revision": "1e1348212798dca75aba72bee0965f95",
    "url": "./static/media/menu-boczne-kwestionariusz_BLUE.1e134821.svg"
  },
  {
    "revision": "cf01afe69ba1642d16909250c4fec34f",
    "url": "./static/media/menu-boczne-kwestionariusz_RED.cf01afe6.svg"
  },
  {
    "revision": "7c299515aeda456ed4938579ceb46280",
    "url": "./static/media/menu-boczne-moje-dane_BLUE.7c299515.svg"
  },
  {
    "revision": "7682179c84578358106fe1b54daaf250",
    "url": "./static/media/menu-boczne-polityka-prywatnosci_BLUE.7682179c.svg"
  },
  {
    "revision": "6741ae7783ae7d72ac630be1c085aac3",
    "url": "./static/media/menu-boczne-ustawienia_BLUE.6741ae77.svg"
  },
  {
    "revision": "ab73662ef077b51ce49e1f890479f219",
    "url": "./static/media/mg.ab73662e.svg"
  },
  {
    "revision": "969819c2742f10e771d1223fbc74dc6b",
    "url": "./static/media/mh.969819c2.svg"
  },
  {
    "revision": "c62e58182c822bdfde3f570b8b7aa008",
    "url": "./static/media/mk.c62e5818.svg"
  },
  {
    "revision": "c931aaa189afa74fe94ceeb2a96d7acc",
    "url": "./static/media/ml.c931aaa1.svg"
  },
  {
    "revision": "386487d6f353578e4aa71d865add7068",
    "url": "./static/media/mm.386487d6.svg"
  },
  {
    "revision": "b2185c1f22dd3d91140ee15771c19bab",
    "url": "./static/media/mn.b2185c1f.svg"
  },
  {
    "revision": "59c91c04aa040e60c908076f98fcb88e",
    "url": "./static/media/mo.59c91c04.svg"
  },
  {
    "revision": "7e3550d74cb0379fee19ce084858abf3",
    "url": "./static/media/mp.7e3550d7.svg"
  },
  {
    "revision": "61a53cf5d503e731ff4136c9d1dbdee4",
    "url": "./static/media/mq.61a53cf5.svg"
  },
  {
    "revision": "cb62979151515ad6d7b5d15a2c841f6b",
    "url": "./static/media/mr.cb629791.svg"
  },
  {
    "revision": "cbd3f274eaf55565f3015e3e6b9a9479",
    "url": "./static/media/ms.cbd3f274.svg"
  },
  {
    "revision": "dd04a6973ff46652227d4691be00d98e",
    "url": "./static/media/mt.dd04a697.svg"
  },
  {
    "revision": "8400b4ab760a6e3b6b917b1243f83e93",
    "url": "./static/media/mu.8400b4ab.svg"
  },
  {
    "revision": "6ef586428bfd6dcf9f44e1660a452e7a",
    "url": "./static/media/mv.6ef58642.svg"
  },
  {
    "revision": "3a771f57bfe922d66ac2f239bf7f6b03",
    "url": "./static/media/mw.3a771f57.svg"
  },
  {
    "revision": "434d6364f29c9e18ba5ff09fb081128c",
    "url": "./static/media/mx.434d6364.svg"
  },
  {
    "revision": "cd942bda71b2fbefa3957ea414e48b65",
    "url": "./static/media/my.cd942bda.svg"
  },
  {
    "revision": "aff3b04af4ebac602e243e79fe4333f7",
    "url": "./static/media/mz.aff3b04a.svg"
  },
  {
    "revision": "e60de66385b16009fcb5dfa598e13a50",
    "url": "./static/media/na.e60de663.svg"
  },
  {
    "revision": "0ade7442ebd6579de6b03641681ed1c5",
    "url": "./static/media/nato.0ade7442.svg"
  },
  {
    "revision": "13e02dc692f1ae62cae90b7c56cebd47",
    "url": "./static/media/ne.13e02dc6.svg"
  },
  {
    "revision": "8b6629d91236f5d18d9c6ef78612c6e1",
    "url": "./static/media/nf.8b6629d9.svg"
  },
  {
    "revision": "dda0e5c84f1d80b117fb200dd08a0021",
    "url": "./static/media/ng.dda0e5c8.svg"
  },
  {
    "revision": "87480e3d44c018beab79dd61ccb8b5df",
    "url": "./static/media/ni.87480e3d.svg"
  },
  {
    "revision": "4daecacbf81009028828c8b63cdebfb8",
    "url": "./static/media/nl.4daecacb.svg"
  },
  {
    "revision": "d3ab6c2834d8cd2715fedcb2771b8ecf",
    "url": "./static/media/no.d3ab6c28.svg"
  },
  {
    "revision": "ce491885444b2ecaf2e5d90ee081e5d0",
    "url": "./static/media/not_supported_logo.ce491885.svg"
  },
  {
    "revision": "2cc22eaf1b55c60073f53547b050b6d1",
    "url": "./static/media/notifi_close.2cc22eaf.svg"
  },
  {
    "revision": "50a03631e8b704d7c3640c091930e39f",
    "url": "./static/media/notifications.50a03631.svg"
  },
  {
    "revision": "9f2d8bc5fc663316bf9f6cda104aca6e",
    "url": "./static/media/np.9f2d8bc5.svg"
  },
  {
    "revision": "a00df6c7c2807376a6e12ff0ff72478b",
    "url": "./static/media/nr.a00df6c7.svg"
  },
  {
    "revision": "4d01f4d617b31034796186e2ec14cfab",
    "url": "./static/media/nu.4d01f4d6.svg"
  },
  {
    "revision": "6bb1f1bd2e0df838b93f3c6692d3c45d",
    "url": "./static/media/nz.6bb1f1bd.svg"
  },
  {
    "revision": "289c4ffe31e0b84ecfc69e42d91bda6b",
    "url": "./static/media/om.289c4ffe.svg"
  },
  {
    "revision": "0b468e395103cc0594b0daed90fbed0d",
    "url": "./static/media/pa.0b468e39.svg"
  },
  {
    "revision": "20bd6f7b3e2b12f56556a98412af6ecc",
    "url": "./static/media/pe.20bd6f7b.svg"
  },
  {
    "revision": "1398e1c87dfe19af92fa2db41f6b78ec",
    "url": "./static/media/pf.1398e1c8.svg"
  },
  {
    "revision": "779acb7331dafc5407baf23b3f491271",
    "url": "./static/media/pg.779acb73.svg"
  },
  {
    "revision": "ba51f2ba424c001fc34cb7a2ee050571",
    "url": "./static/media/ph.ba51f2ba.svg"
  },
  {
    "revision": "c519e9b1bae09ee95355e5e35bcd1d0e",
    "url": "./static/media/pk.c519e9b1.svg"
  },
  {
    "revision": "f6afdb6282dbc143f635c20037a9728e",
    "url": "./static/media/pl.f6afdb62.svg"
  },
  {
    "revision": "0727a66f40d2ccac775bafaa7881eeba",
    "url": "./static/media/plus.0727a66f.svg"
  },
  {
    "revision": "250c320b86c35d0dd6a9038c6f7039b4",
    "url": "./static/media/pn.250c320b.svg"
  },
  {
    "revision": "7477154a0cf29d7c66f4d4e43a09cd53",
    "url": "./static/media/pr.7477154a.svg"
  },
  {
    "revision": "21fc84a48e151bb226e53a837b80c295",
    "url": "./static/media/protegosafe_logo_white.21fc84a4.svg"
  },
  {
    "revision": "33a2122adcb1d83a3ddac036db450d0d",
    "url": "./static/media/ps.33a2122a.svg"
  },
  {
    "revision": "55a651f808fedde314286a00cec23e78",
    "url": "./static/media/pt.55a651f8.svg"
  },
  {
    "revision": "667ce732707efae02e07f118c7cb6e39",
    "url": "./static/media/pw.667ce732.svg"
  },
  {
    "revision": "1a604331bdbe71a860e6da96cf4c4693",
    "url": "./static/media/py.1a604331.svg"
  },
  {
    "revision": "b1303a153be1bfe3153c843dc1b251b7",
    "url": "./static/media/qa.b1303a15.svg"
  },
  {
    "revision": "55ec211cec00192b94d26a34319ba3b0",
    "url": "./static/media/reka-aktywny.55ec211c.svg"
  },
  {
    "revision": "dec1500ec283e6d7f4546ac6458e6968",
    "url": "./static/media/reka-nieaktywny.dec1500e.svg"
  },
  {
    "revision": "a27663462acdacd9d6a081998504a1b0",
    "url": "./static/media/reka-test.a2766346.svg"
  },
  {
    "revision": "677089b70c32c0dd3175efb1344b862d",
    "url": "./static/media/reka-test_noti.677089b7.svg"
  },
  {
    "revision": "dd4d10967760e8dce552d4cbdf3dce4b",
    "url": "./static/media/risk-test-recommendation-high.dd4d1096.svg"
  },
  {
    "revision": "63ccef38f704c1502bddc051b76b44ed",
    "url": "./static/media/risk-test-recommendation-middle.63ccef38.svg"
  },
  {
    "revision": "435572890534ad09201d7b78b724b87f",
    "url": "./static/media/risk-test-result-high.43557289.svg"
  },
  {
    "revision": "0d3513ad7fd0138434248a3685ed2df9",
    "url": "./static/media/risk-test-result-low.0d3513ad.svg"
  },
  {
    "revision": "1fbebff5b3f27148a318bae8471f0790",
    "url": "./static/media/risk-test-result-middle.1fbebff5.svg"
  },
  {
    "revision": "3b593c62d8a5d94bc7725b2bd0c65a04",
    "url": "./static/media/risk-test-small.3b593c62.svg"
  },
  {
    "revision": "583d46885330f9689ef73462d82f5a2e",
    "url": "./static/media/ro.583d4688.svg"
  },
  {
    "revision": "eb3be364f4870d574be35ad83e1be820",
    "url": "./static/media/rs.eb3be364.svg"
  },
  {
    "revision": "4336677bb1fbd65733809573bb256682",
    "url": "./static/media/ru.4336677b.svg"
  },
  {
    "revision": "b586ef696d05d86f3134d2dbb1533672",
    "url": "./static/media/rw.b586ef69.svg"
  },
  {
    "revision": "479bb907f17a17b69478443d24027a6c",
    "url": "./static/media/sa.479bb907.svg"
  },
  {
    "revision": "40725ee9b822ec6f5ff60aff376ea674",
    "url": "./static/media/sb.40725ee9.svg"
  },
  {
    "revision": "74bd1af95f5aa121f40fe53fb08344a2",
    "url": "./static/media/sc.74bd1af9.svg"
  },
  {
    "revision": "808944c35f7a3fba5e789e500f3cc056",
    "url": "./static/media/sd.808944c3.svg"
  },
  {
    "revision": "ea2a67f515d9992e998c6bc8a2199493",
    "url": "./static/media/se.ea2a67f5.svg"
  },
  {
    "revision": "5e6527638858205ca0f576074c8c8f2f",
    "url": "./static/media/sg.5e652763.svg"
  },
  {
    "revision": "4279aabf6bd2e738498988419fe2e67e",
    "url": "./static/media/si.4279aabf.svg"
  },
  {
    "revision": "6837398cbdff0688428a0ff1ad313098",
    "url": "./static/media/sick-approve.6837398c.svg"
  },
  {
    "revision": "6a384c6bc74bd2c53e96b5156d9b8bf1",
    "url": "./static/media/sick-reported.6a384c6b.svg"
  },
  {
    "revision": "e995322edc4aa2749ed9d34a21be69da",
    "url": "./static/media/sk.e995322e.svg"
  },
  {
    "revision": "0ab96fdfe4e80b29767ffdf7c7e939fd",
    "url": "./static/media/sl.0ab96fdf.svg"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "./static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "./static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "./static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "./static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "c4ee42b3c4beaeb81088bc5ceba19de8",
    "url": "./static/media/sm.c4ee42b3.svg"
  },
  {
    "revision": "bf1181f542aeddbfbbd2836c4ad26790",
    "url": "./static/media/smile-green.bf1181f5.svg"
  },
  {
    "revision": "1569aca0cb46b2ca655c964006c337de",
    "url": "./static/media/sn.1569aca0.svg"
  },
  {
    "revision": "dc2fb9befc0991f247021eb226d3875a",
    "url": "./static/media/so.dc2fb9be.svg"
  },
  {
    "revision": "a96b947d3e01d617afbb1d8d3ddb9ac0",
    "url": "./static/media/sr.a96b947d.svg"
  },
  {
    "revision": "49471e3c27c0db5ad966532bd9059f13",
    "url": "./static/media/ss.49471e3c.svg"
  },
  {
    "revision": "abdc56036d300ba07f70226de839e675",
    "url": "./static/media/st.abdc5603.svg"
  },
  {
    "revision": "c34a62eeb449c58a9000825a9d5fd839",
    "url": "./static/media/star-outline.c34a62ee.svg"
  },
  {
    "revision": "60204e7a68703a92ab271596de72224c",
    "url": "./static/media/star-solid.60204e7a.svg"
  },
  {
    "revision": "fcb93243e5a8a1c616bcc125379aa587",
    "url": "./static/media/stop-covid-logo.fcb93243.svg"
  },
  {
    "revision": "20df34b66f2be3ecb20a39c6b7dd39ed",
    "url": "./static/media/stopcovid_protegosafe_logo_sygnet.20df34b6.svg"
  },
  {
    "revision": "d0c2cfff17a1a77885cbb51f508836ac",
    "url": "./static/media/success-icon.d0c2cfff.svg"
  },
  {
    "revision": "a80a402cb9588b0da1f11446c0953610",
    "url": "./static/media/success.a80a402c.svg"
  },
  {
    "revision": "7aecb11535b343c812a0bad1be7b2867",
    "url": "./static/media/sv.7aecb115.svg"
  },
  {
    "revision": "c70e8d706231569d5cabbb0f674b70e4",
    "url": "./static/media/sx.c70e8d70.svg"
  },
  {
    "revision": "6065fa1603db028d536d816207b2537f",
    "url": "./static/media/sy.6065fa16.svg"
  },
  {
    "revision": "3fd422e9ee9cbfa1a791999d380b1967",
    "url": "./static/media/sz.3fd422e9.svg"
  },
  {
    "revision": "3886447add7caba05dd7b9f9910a15f2",
    "url": "./static/media/tc.3886447a.svg"
  },
  {
    "revision": "97c1759bef4ec5fc7a5b578543d31770",
    "url": "./static/media/td.97c1759b.svg"
  },
  {
    "revision": "c7f34ff0db0140b376c3b4779c33cb64",
    "url": "./static/media/telefon-reka.c7f34ff0.svg"
  },
  {
    "revision": "edb371079c8d62a14a4e413d9523fcf1",
    "url": "./static/media/testy.edb37107.svg"
  },
  {
    "revision": "e0f4483533c48a7c0ede0109b5fbda5d",
    "url": "./static/media/tg.e0f44835.svg"
  },
  {
    "revision": "5f831e47acb96985d8a8f7dea0065715",
    "url": "./static/media/th.5f831e47.svg"
  },
  {
    "revision": "c7beb8fb8dcae616250b42051209688e",
    "url": "./static/media/three-people.c7beb8fb.svg"
  },
  {
    "revision": "3f00c818cbac4c1a5c0d0c68dbbf31d4",
    "url": "./static/media/tibet.3f00c818.svg"
  },
  {
    "revision": "88ea306ff9923b46373b9c2fce39dc90",
    "url": "./static/media/tj.88ea306f.svg"
  },
  {
    "revision": "595812eb4c8e8e3752c683ea50dd3340",
    "url": "./static/media/tk.595812eb.svg"
  },
  {
    "revision": "33f1c1cd801d785dabbe6c77a45f21c3",
    "url": "./static/media/tm.33f1c1cd.svg"
  },
  {
    "revision": "c17b985c33137f61b29fdec1b1ec9efb",
    "url": "./static/media/tn.c17b985c.svg"
  },
  {
    "revision": "ec77d856b2ac7bd115f9d81dde8887e5",
    "url": "./static/media/to.ec77d856.svg"
  },
  {
    "revision": "28b8c158347dba2fed728a76bc81ad0b",
    "url": "./static/media/tr.28b8c158.svg"
  },
  {
    "revision": "fbc6495cc65864e3c49a5947cd6e1b0c",
    "url": "./static/media/tt.fbc6495c.svg"
  },
  {
    "revision": "eb5ef829d502fc08a2211c7a79b1cbf4",
    "url": "./static/media/tv.eb5ef829.svg"
  },
  {
    "revision": "9374cc2926c2948d6fe65b95045fccca",
    "url": "./static/media/tw.9374cc29.svg"
  },
  {
    "revision": "ec5a26d3645c8bee4d17f49cf4066081",
    "url": "./static/media/tz.ec5a26d3.svg"
  },
  {
    "revision": "1c23b8c9945e4fab0ad0631cacb0f20e",
    "url": "./static/media/ua.1c23b8c9.svg"
  },
  {
    "revision": "e80e04132cc080dcc071da5f9e6eccc5",
    "url": "./static/media/ug.e80e0413.svg"
  },
  {
    "revision": "1c23b8c9945e4fab0ad0631cacb0f20e",
    "url": "./static/media/uk.1c23b8c9.svg"
  },
  {
    "revision": "fa563627097b131b0da1075bbd4a9cba",
    "url": "./static/media/us.fa563627.svg"
  },
  {
    "revision": "1a19a019552141ec2f40ae64fbbff5f4",
    "url": "./static/media/user-message.1a19a019.svg"
  },
  {
    "revision": "6afe5efa72239d92b911c923c95ecaf4",
    "url": "./static/media/uy.6afe5efa.svg"
  },
  {
    "revision": "f32eacef6c921a7e25a16617757f5f7b",
    "url": "./static/media/uz.f32eacef.svg"
  },
  {
    "revision": "89aac662cc303834cef7126ef4659570",
    "url": "./static/media/ve.89aac662.svg"
  },
  {
    "revision": "9089b8e3e7a3c0ed474f01050b300fa8",
    "url": "./static/media/vi.9089b8e3.svg"
  },
  {
    "revision": "87fef27265d241c053a6f24683a7c454",
    "url": "./static/media/virus-high.87fef272.svg"
  },
  {
    "revision": "676d8204d9b1bc15f70df9ee80e9ab0b",
    "url": "./static/media/virus-small.676d8204.svg"
  },
  {
    "revision": "3e303f7f120428c7caf219d1d3c8596a",
    "url": "./static/media/vn.3e303f7f.svg"
  },
  {
    "revision": "3b3fcfb40964bb9cf13378ce93c3fc48",
    "url": "./static/media/vu.3b3fcfb4.svg"
  },
  {
    "revision": "82b8fa2a1cfd32532c5b68782ce4c59e",
    "url": "./static/media/warning-current-color.82b8fa2a.svg"
  },
  {
    "revision": "0bfb0413158cd54c24c2b441b62f55b0",
    "url": "./static/media/warning.0bfb0413.svg"
  },
  {
    "revision": "475281bde6c6966dac3e8db69f2eb962",
    "url": "./static/media/warning.475281bd.svg"
  },
  {
    "revision": "607bd1642d410ca5a55172fd551bc5b0",
    "url": "./static/media/welcome-screen.607bd164.svg"
  },
  {
    "revision": "6d92b2e4db64cdf8dd3deefd957be2c1",
    "url": "./static/media/ws.6d92b2e4.svg"
  },
  {
    "revision": "6e17f48b0f0bbdbd0aca2b8f6f29a09f",
    "url": "./static/media/wykonaj-test.6e17f48b.svg"
  },
  {
    "revision": "20c6e27ff9f778328c45c21c461c760e",
    "url": "./static/media/ye.20c6e27f.svg"
  },
  {
    "revision": "4b07683a3c129b75608aeb672541af5d",
    "url": "./static/media/za.4b07683a.svg"
  },
  {
    "revision": "acad9df90b4ac790162442fe2de03af4",
    "url": "./static/media/zm.acad9df9.svg"
  },
  {
    "revision": "bd54e200ac3229e3c318ff0816ad29ea",
    "url": "./static/media/zw.bd54e200.svg"
  }
]);